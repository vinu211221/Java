
class vasu{
    public static int cal(int x, int y){
        int z=(x+y);
        return z;

    }
    public static int cal(int a ,int b,int c){
        int d=(a+b)-c;
        return d;

    }
    public static int cal(int i,int j,int k,int l){
        int m=(i+j)-k/l;
        return m;
    }

    public static void main(String[] args) {

        System.out.println(("z "+cal(5,6)));
        System.out.println(("d "+cal(10,5,3)));
        System.out.println(("m "+cal(2,4,8,20)));
    }


















public class ClassO {



    }

}
