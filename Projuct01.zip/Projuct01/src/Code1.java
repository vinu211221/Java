public class Code1 {
    public static void main(String[] args) {
        System.out.println("hello");
        int x = 8;
        int y = 16;

        System.out.println(x - y);
        System.out.println(x + y);
        System.out.println(x * y);
        System.out.println(x / y);
        System.out.println(x % y);
        System.out.println(x > y);

    }
}



