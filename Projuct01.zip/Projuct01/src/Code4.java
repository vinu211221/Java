public class Code4 {
    public static void main(String[] args) {
        String str= "VASUNDHARA";
        String str1="vasundhara";
        System.out.println(str.length());
        System.out.println(str.toLowerCase());
        System.out.println(str.replace("A","O"));
    }
}
