public class Code5 {
    public static void main(String[] args) {
        String str="thiruvananthapuram";
        System.out.println(str.length());
        System.out.println(str.toUpperCase());
        System.out.println(str.replace("a","v"));
    }
}
