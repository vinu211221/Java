import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Code6 {
    public static void main(String[] args) throws IOException {
        int i;
        int j;
        int k;
        int l;
        int m;
        int z;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the Five Value");
        System.out.println("i");
        i = Integer.parseInt(br.readLine());
        System.out.println("j");
        j = Integer.parseInt(br.readLine());
        System.out.println("k");
        k = Integer.parseInt(br.readLine());
        System.out.println("l");
        l = Integer.parseInt(br.readLine());
        System.out.println("m");
        m = Integer.parseInt(br.readLine());
        z=(i+j+k+l+m)/5;
        System.out.println("average" +z);

        if (z>=90) {
            System.out.println("you will get bycicle");} else if (z>70 && z<90) {
            System.out.println("you will get chocolate");} else {
            System.out.println("study hard");}



        }
}

            





