import java.util.ArrayList;

public class arreylist1 {
    public static void main(String[] args) {
        ArrayList<String> arr= new ArrayList<String>();
        arr .add("mumbai"); arr .add("pune"); arr .add("satara"); arr .add(1,"nashik");
        System.out.println(arr.size());
        System.out.println(arr.get(2));
        System.out.println(arr.isEmpty());
        arr.remove(3);
        System.out.println(arr .get(3));

    }
}
