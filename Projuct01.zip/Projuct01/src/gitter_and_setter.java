import java.util.Scanner;

class ked {
    int redius;
    Double area;

    public void set(int r){
        this.redius = r;
    }

    public double getRedius() {

        return redius;
    }

    public Double area(){
        double z=3.412*redius*redius;
        return z;
    }

}
public class gitter_and_setter {
    public static void main(String[] args) {
        ked g=new ked();
        Scanner sc= new Scanner(System.in);
        System.out.println("enter the value of redius");
        int r=sc.nextInt();
        g.set(r);
        g.area();
        System.out.println(g.getRedius());
        System.out.println(g.area());
    }
}
