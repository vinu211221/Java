class cal {
    public int cal_add(int x, int y) {
        int z = x + y;
        System.out.println(z);
        return z;
    }


}
class cal1 extends cal {
    public int cal_sub(int x, int y) {
        int z= x - y;
        System.out.println(z);
        return z;
    }
}
class cal2 extends cal1 {
    public int cal_multy(int x, int y) {
        int z=x * y;
        System.out.println(z);
        return z;
    }
}
class cal3 extends cal2 {
        public int cal_division(int x, int y){
            int z= x/y;
            System.out.println(z);
            return z;

        }
   }


public class inherit {
    public static void main(String[] args) {
        cal3 c=new cal3();
        c.cal_division(3,8);
        c.cal_sub(3,7);
        c.cal_multy(4,5);
        c.cal_division(4,2);








    }
}
