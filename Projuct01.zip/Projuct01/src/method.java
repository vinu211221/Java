class moolya{
    public static int add(int x,int y){
        int z;
       z= x + y;
        System.out.println(+z);
        return z;



    }
    public static int sub(int x,int y){
        int z;
        z= x - y;
       System.out.println(+z);
       return z;


    }
    public static int multiply(int x,int y){
        int z;
         z= x * y;
        System.out.println(+z);
        return z;
    }
    public static int division(int x,int y){
        int z;
        z= x / y;
       System.out.println(+z);
       return z;


    }
    public static int modulor(int x,int y){
        int z;
        z= x % y;
        System.out.println(+z);
return z;
    }
public static void area(int r){
        double a= 3.142*r*r;
    System.out.println("area of the circle  "+a);
}
}public class method {
    public static void main(String[] args) {
        moolya.add(10,20);
        moolya.sub(10,35);
        moolya.multiply(20,5);
        moolya.division(10,4);
        moolya.modulor(10,4);
        moolya.area(4);



    }
}
