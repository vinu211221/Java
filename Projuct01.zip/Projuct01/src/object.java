public class object {
    public int add(int x,int y){
        int sum=x+y;
        return sum;

    }
    public static void main(String[] args) {
        object obj=new object();
        System.out.println(obj.add(10,5));

    }
}
