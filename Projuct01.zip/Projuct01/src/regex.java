class reg{
    int mb_num; String name; String regex="^[a-zA-Z]+$";
    public void set(int mb_num1, String name1){
        this.mb_num=mb_num1;
        if (name1.matches(regex)){
            this.name=name1;
        }else {
            System.out.println("wrong name set");
        }

    }

    public int getMb_num() {
        return mb_num;
    }

    public String getName() {
        return name;
    }
}
public class regex {
    public static void main(String[] args) {
        reg r= new reg();
        r.set(9870,"Vasundhara327");
        System.out.println(r.getMb_num());
        System.out.println(r.getName());

    }


}
