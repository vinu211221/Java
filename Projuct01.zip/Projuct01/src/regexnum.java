import java.util.Scanner;

public class regexnum {
    public static void main(String[] args) {
        String regex = "^\\d{10}";
        System.out.println("Enter input value: ");
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        boolean result = input.matches(regex);
        if(result) {
            System.out.println("10 digit number");
        } else {
            System.out.println("wrong input");
        }
    }
}


