public class verarg {

    public int product(int...arr){
        int product=1;
        System.out.println("length "+arr.length);
        for (int i=0;i<arr.length;i++) {
            product = product*arr[i];

        }return product;


    }

      public static void main(String[] args) {
        verarg v=new verarg();
        int y= v.product(4,6,8,6,5,6);
          System.out.println( +y);


    }
}
